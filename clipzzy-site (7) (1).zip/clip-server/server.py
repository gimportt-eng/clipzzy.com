"""Clipzzy server: landing page, clipper app, pricing, customer accounts, link-clipping API.

Run:   pip install -r requirements.txt   (ffmpeg must be installed)
       SECRET_KEY=change-me COOKIE_SECURE=0 python server.py   -> http://localhost:8000
Prod:  gunicorn -w 2 -t 300 -b 0.0.0.0:8000 server:app
Admin: python server.py create-admin                          (create the owner account; asks for a password)
       python server.py set-plan user@example.com monthly   (manual override)
       python server.py setup-paypal                         (one-time: create PayPal billing plans)

Only clip content you own or have permission to clip.
"""
import calendar
import hashlib
import hmac
import math
import os
import re
import secrets
import shutil
import sqlite3
import subprocess
import sys
import smtplib
import tempfile
import threading
import time
import uuid
from collections import defaultdict
from functools import wraps
from urllib.parse import urlparse

from email.message import EmailMessage

import requests
from flask import (Flask, after_this_request, g, jsonify, redirect, request, send_file,
                   send_from_directory, session)
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import check_password_hash, generate_password_hash
import yt_dlp
from yt_dlp.utils import download_range_func

HERE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DB_PATH", os.path.join(HERE, "clipzzy.db"))
MAX_CLIP_SECONDS = int(os.environ.get("MAX_CLIP_SECONDS", "300"))
ALLOWED_HOSTS = {
    "youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be",
    "twitch.tv", "www.twitch.tv", "clips.twitch.tv",
}
PLANS = {
    "free": {"name": "Free", "limit": 7, "period": "day", "max_len": 30,
             "height": 720, "watermark": True, "trial_days": 30},
    "weekly": {"name": "Weekly", "limit": 25, "period": "week", "max_len": 180,
               "height": 1080, "watermark": False},       # Telebirr only
    "monthly": {"name": "Monthly", "limit": 100, "period": "month", "max_len": 180,
                "height": 1080, "watermark": False},
    "annual": {"name": "Annual", "limit": None, "period": "month", "max_len": 600,
               "height": 1080, "watermark": False},
}
CLIPS_DIR = os.environ.get("CLIPS_DIR", os.path.join(HERE, "clips"))
LOCK_DAYS = 4                       # clips are available this long, then locked
UNLOCK_CENTS = 400                  # $4.00 to unlock a locked clip
RETAIN_LOCKED_DAYS = int(os.environ.get("RETAIN_LOCKED_DAYS", "30"))  # locked clips deleted after this many extra days
MAX_ACTIVE_CLIPS = int(os.environ.get("MAX_ACTIVE_CLIPS", "50"))
MAX_UPLOAD_MB = int(os.environ.get("MAX_UPLOAD_MB", "200"))
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1)  # one proxy (Render, etc.)
if not os.environ.get("SECRET_KEY"):
    print("WARNING: SECRET_KEY not set; logins reset on every restart.", file=sys.stderr)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "1") == "1",
    PERMANENT_SESSION_LIFETIME=60 * 60 * 24 * 30,
)


# ---------- database ----------
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    conn = g.pop("db", None)
    if conn:
        conn.close()


def init_db():
    with sqlite3.connect(DB_PATH) as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            pw_hash TEXT NOT NULL,
            plan TEXT NOT NULL DEFAULT 'free',
            created_at INTEGER NOT NULL,
            free_start INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS exports(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            at INTEGER NOT NULL);
        CREATE INDEX IF NOT EXISTS exports_user_at ON exports(user_id, at);
        CREATE TABLE IF NOT EXISTS clips(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            path TEXT NOT NULL,
            mime TEXT NOT NULL,
            size INTEGER NOT NULL,
            created_at INTEGER NOT NULL,
            unlocked_at INTEGER);
        CREATE INDEX IF NOT EXISTS clips_user ON clips(user_id, created_at);
        CREATE TABLE IF NOT EXISTS paypal_orders(
            order_id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            clip_id INTEGER NOT NULL,
            created_at INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'created');
        """)
        cols = {r[1] for r in c.execute("PRAGMA table_info(users)")}
        if "sub_id" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN sub_id TEXT")
        if "sub_checked" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN sub_checked INTEGER NOT NULL DEFAULT 0")
        if "plan_until" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN plan_until INTEGER")
        if "session_ver" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN session_ver INTEGER NOT NULL DEFAULT 0")
        if "email_verified" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN email_verified INTEGER NOT NULL DEFAULT 0")
            c.execute("UPDATE users SET email_verified=1")   # accounts that existed before this feature
        c.executescript("""
        CREATE TABLE IF NOT EXISTS email_tokens(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            kind TEXT NOT NULL,
            token_hash TEXT NOT NULL UNIQUE,
            expires_at INTEGER NOT NULL,
            created_at INTEGER NOT NULL);
        """)
        c.executescript("""
        CREATE TABLE IF NOT EXISTS telebirr_payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            kind TEXT NOT NULL,
            plan TEXT,
            clip_id INTEGER,
            amount_etb REAL NOT NULL,
            reference TEXT NOT NULL,
            screenshot TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            note TEXT,
            created_at INTEGER NOT NULL,
            reviewed_at INTEGER);
        CREATE INDEX IF NOT EXISTS tb_status ON telebirr_payments(status, created_at);
        """)


init_db()


# ---------- helpers ----------
def err(msg, code=400):
    return jsonify({"error": msg}), code


HITS = defaultdict(list)


def limited(key, n=10, window=60):
    now = time.time()
    HITS[key] = [t for t in HITS[key] if now - t < window]
    if len(HITS[key]) >= n:
        return True
    HITS[key].append(now)
    return False


def period_start(period):
    now = time.time()
    if period == "day":
        return int(now - now % 86400)
    if period == "week":
        return int(now - 7 * 86400)
    t = time.gmtime()
    return calendar.timegm((t.tm_year, t.tm_mon, 1, 0, 0, 0))


def current_user():
    uid = session.get("uid")
    if not uid:
        return None
    row = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not row or session.get("sv", 0) != row["session_ver"]:
        return None
    return row


def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        u = current_user()
        if not u:
            return err("Please log in or sign up at /register first.", 401)
        return fn(u, *a, **kw)
    return wrapper


def profile(u):
    p = PLANS[u["plan"]]
    used = db().execute("SELECT COUNT(*) FROM exports WHERE user_id=? AND at>=?",
                        (u["id"], period_start(p["period"]))).fetchone()[0]
    out = {"email": u["email"], "plan": u["plan"], "plan_name": p["name"],
           "used": used, "limit": p["limit"], "period": p["period"],
           "max_len": min(p["max_len"], MAX_CLIP_SECONDS),
           "email_verified": bool(u["email_verified"]), "verification_required": email_enabled()}
    if u["plan_until"] and not u["sub_id"] and u["plan"] != "free":
        out["plan_until"] = u["plan_until"]
    if u["plan"] == "free":
        left = p["trial_days"] - (time.time() - u["free_start"]) / 86400
        out["trial_days_left"] = max(0, math.ceil(left))
    return out


def start_session(uid, sv=0):
    session.clear()
    session["uid"] = uid
    session["sv"] = sv
    session.permanent = True


# ---------- pages ----------
@app.get("/")
def index():
    return send_from_directory(HERE, "index.html")


@app.get("/app")
def clipper_app():
    return send_from_directory(HERE, "clipper.html")


@app.get("/pricing")
def pricing():
    return send_from_directory(HERE, "pricing.html")


@app.get("/pay/telebirr")
def telebirr_page():
    return send_from_directory(HERE, "telebirr.html")


@app.get("/admin/payments")
def admin_payments_page():
    return send_from_directory(HERE, "admin-payments.html")


@app.get("/help")
def help_page():
    return send_from_directory(HERE, "help.html")


@app.get("/terms")
def terms_page():
    return send_from_directory(HERE, "terms.html")


@app.get("/register")
def register_page():
    return send_from_directory(HERE, "register.html")


# ---------- accounts ----------
@app.post("/api/register")
def register():
    if not request.is_json:
        return err("JSON required.")
    if limited("reg:" + (request.remote_addr or "?")):
        return err("Too many attempts. Try again in a minute.", 429)
    d = request.get_json(silent=True) or {}
    email = str(d.get("email", "")).strip().lower()
    pw = str(d.get("password", ""))
    if not EMAIL_RE.match(email) or len(email) > 254:
        return err("Enter a valid email address.")
    if not 8 <= len(pw) <= 128:
        return err("Password must be 8 to 128 characters.")
    if d.get("agree") is not True:
        return err("Please agree to the terms to continue.")
    if email in admin_emails():
        return err("This email address is reserved. Please use a different email.", 403)
    now = int(time.time())
    try:
        cur = db().execute(
            "INSERT INTO users(email,pw_hash,plan,created_at,free_start) VALUES(?,?,?,?,?)",
            (email, generate_password_hash(pw), "free", now, now))
        db().commit()
    except sqlite3.IntegrityError:
        return err("That email is already registered. Try logging in.", 409)
    start_session(cur.lastrowid, 0)
    new_user = current_user()
    send_verification(new_user)
    return jsonify(profile(new_user)), 201


@app.post("/api/login")
def login():
    if not request.is_json:
        return err("JSON required.")
    if limited("login:" + (request.remote_addr or "?")):
        return err("Too many attempts. Try again in a minute.", 429)
    d = request.get_json(silent=True) or {}
    email = str(d.get("email", "")).strip().lower()
    u = db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if not u or not check_password_hash(u["pw_hash"], str(d.get("password", ""))):
        return err("Wrong email or password.", 401)
    start_session(u["id"], u["session_ver"])
    return jsonify(profile(u))


@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify({"ok": True})


@app.get("/api/me")
@login_required
def me(u):
    return jsonify(profile(refresh_subscription(u)))


# ---------- clipping ----------
def add_watermark(src, dst):
    vf = ("drawtext=text='ananya.clip':fontcolor=white@0.75:"
          "fontsize=h/22:x=w-tw-16:y=h-th-16")
    subprocess.run(["ffmpeg", "-y", "-i", src, "-vf", vf, "-c:a", "copy", dst],
                   check=True, capture_output=True, timeout=280)


@app.post("/api/clip")
@login_required
def clip(u):
    blocked = unverified(u)
    if blocked:
        return blocked
    if not request.is_json:
        return err("JSON required.")
    data = request.get_json(silent=True) or {}
    if data.get("confirm_rights") is not True:
        return err("You must confirm you own this content or have permission to clip it.")

    url = str(data.get("url", ""))
    host = (urlparse(url).hostname or "").lower()
    if urlparse(url).scheme not in ("http", "https") or host not in ALLOWED_HOSTS:
        return err("Only YouTube and Twitch links are supported.")
    try:
        start, end = float(data["start"]), float(data["end"])
    except (KeyError, TypeError, ValueError):
        return err("start and end must be numbers (seconds).")
    if start < 0 or end <= start:
        return err("end must be greater than start.")

    u = refresh_subscription(u)
    plan, pf = PLANS[u["plan"]], profile(u)
    if u["plan"] == "free" and pf["trial_days_left"] <= 0:
        return err("Your 30-day free period has ended. Please upgrade to keep exporting.", 403)
    if pf["limit"] is not None and pf["used"] >= pf["limit"]:
        return err(f"You have used all {pf['limit']} exports for this {pf['period']}.", 403)
    if end - start > pf["max_len"]:
        return err(f"Clips on the {plan['name']} plan can be up to {pf['max_len']} seconds.", 403)

    tmp = tempfile.mkdtemp(prefix="clip_")

    @after_this_request
    def cleanup(response):
        shutil.rmtree(tmp, ignore_errors=True)
        return response

    h = plan["height"]
    opts = {
        "format": f"bv*[height<={h}]+ba/b[height<={h}]",
        "download_ranges": download_range_func(None, [(start, end)]),
        "force_keyframes_at_cuts": True,
        "merge_output_format": "mp4",
        "outtmpl": os.path.join(tmp, "clip.%(ext)s"),
        "noplaylist": True,
        "quiet": True,
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([url])
    except Exception as e:  # yt-dlp raises several error types
        return err(f"Could not download that video: {e}", 502)

    files = [f for f in os.listdir(tmp) if f.endswith(".mp4")]
    if not files:
        return err("No clip was produced.", 502)
    out = os.path.join(tmp, files[0])
    if plan["watermark"]:
        marked = os.path.join(tmp, "marked.mp4")
        try:
            add_watermark(out, marked)
        except Exception:
            return err("Could not finish the clip. Please try again.", 500)
        out = marked

    db().execute("INSERT INTO exports(user_id, at) VALUES(?,?)", (u["id"], int(time.time())))
    db().commit()
    title = str(data.get("title", "")).strip()[:120] or "Clip from link"
    saved = store_clip(u, out, "video/mp4", title)
    resp = send_file(out, mimetype="video/mp4", as_attachment=True, download_name="clip.mp4")
    resp.headers["X-Clip-Saved"] = "1" if saved else "0"
    return resp


# ---------- saved clips (4 days, then locked until unlocked for $4) ----------
def clip_status(row, now=None):
    now = now or time.time()
    if row["unlocked_at"]:
        return "unlocked"
    return "active" if now < row["created_at"] + LOCK_DAYS * 86400 else "locked"


def clip_json(row):
    now = time.time()
    st = clip_status(row, now)
    out = {"id": row["id"], "title": row["title"], "size": row["size"],
           "created_at": row["created_at"], "status": st, "price_cents": UNLOCK_CENTS}
    if st == "active":
        out["seconds_left"] = int(row["created_at"] + LOCK_DAYS * 86400 - now)
    return out


def active_count(u):
    rows = db().execute("SELECT * FROM clips WHERE user_id=?", (u["id"],)).fetchall()
    return sum(1 for r in rows if clip_status(r) != "locked")


def remove_clip_file(row):
    try:
        os.remove(os.path.join(CLIPS_DIR, row["path"]))
    except OSError:
        pass


def purge_old(u):
    cutoff = time.time() - (LOCK_DAYS + RETAIN_LOCKED_DAYS) * 86400
    old = db().execute("SELECT * FROM clips WHERE user_id=? AND unlocked_at IS NULL AND created_at<?",
                       (u["id"], cutoff)).fetchall()
    for r in old:
        remove_clip_file(r)
        db().execute("DELETE FROM clips WHERE id=?", (r["id"],))
    if old:
        db().commit()


def store_clip(u, src, mime, title):
    """Copy a finished clip into storage and record it. Returns the new id or None."""
    if active_count(u) >= MAX_ACTIVE_CLIPS:
        return None
    ext = "webm" if "webm" in mime else "mp4"
    rel = os.path.join(str(u["id"]), uuid.uuid4().hex + "." + ext)
    dest = os.path.join(CLIPS_DIR, rel)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    shutil.copyfile(src, dest)
    cur = db().execute(
        "INSERT INTO clips(user_id,title,path,mime,size,created_at) VALUES(?,?,?,?,?,?)",
        (u["id"], title, rel, mime, os.path.getsize(dest), int(time.time())))
    db().commit()
    return cur.lastrowid


def owned_clip(u, cid):
    return db().execute("SELECT * FROM clips WHERE id=? AND user_id=?", (cid, u["id"])).fetchone()


@app.get("/clips")
def clips_page():
    return send_from_directory(HERE, "clips.html")


@app.get("/api/clips")
@login_required
def list_clips(u):
    purge_old(u)
    rows = db().execute("SELECT * FROM clips WHERE user_id=? ORDER BY created_at DESC", (u["id"],)).fetchall()
    return jsonify({"clips": [clip_json(r) for r in rows], "lock_days": LOCK_DAYS,
                    "price_cents": UNLOCK_CENTS})


@app.post("/api/clips/upload")
@login_required
def upload_clip(u):
    blocked = unverified(u)
    if blocked:
        return blocked
    f = request.files.get("file")
    if not f:
        return err("No file received.")
    if f.mimetype not in ("video/webm", "video/mp4"):
        return err("Only WebM or MP4 clips can be saved.")
    if active_count(u) >= MAX_ACTIVE_CLIPS:
        return err(f"You can keep up to {MAX_ACTIVE_CLIPS} clips at a time. Delete some first.", 409)
    title = str(request.form.get("title", "")).strip()[:120] or "Untitled clip"
    tmp = tempfile.NamedTemporaryFile(delete=False)
    try:
        f.save(tmp)
        tmp.close()
        if os.path.getsize(tmp.name) == 0:
            return err("The file is empty.")
        cid = store_clip(u, tmp.name, f.mimetype, title)
    finally:
        try:
            os.remove(tmp.name)
        except OSError:
            pass
    return jsonify(clip_json(owned_clip(u, cid))), 201


@app.get("/api/clips/<int:cid>/file")
@login_required
def clip_file(u, cid):
    row = owned_clip(u, cid)
    if not row:
        return err("Clip not found.", 404)
    if clip_status(row) == "locked":
        return err(f"This clip is locked. Unlock it for ${UNLOCK_CENTS / 100:.0f} to watch or download it.", 402)
    path = os.path.join(CLIPS_DIR, row["path"])
    if not os.path.exists(path):
        return err("The file is no longer available.", 404)
    ext = "webm" if "webm" in row["mime"] else "mp4"
    return send_file(path, mimetype=row["mime"], as_attachment=request.args.get("download") == "1",
                     download_name=re.sub(r"[^\w\- ]", "", row["title"]).strip() + "." + ext
                     if row["title"] else "clip." + ext)


@app.post("/api/clips/<int:cid>/delete")
@login_required
def delete_clip(u, cid):
    if not request.is_json:
        return err("JSON required.")
    row = owned_clip(u, cid)
    if not row:
        return err("Clip not found.", 404)
    remove_clip_file(row)
    db().execute("DELETE FROM clips WHERE id=?", (cid,))
    db().commit()
    return jsonify({"ok": True})


def paypal_base():
    return ("https://api-m.paypal.com" if os.environ.get("PAYPAL_ENV") == "live"
            else "https://api-m.sandbox.paypal.com")


def paypal_configured():
    return bool(os.environ.get("PAYPAL_CLIENT_ID") and os.environ.get("PAYPAL_CLIENT_SECRET"))


def paypal_api(method, path, payload=None):
    """Call the PayPal REST API. Returns (http_status, json_dict)."""
    auth = (os.environ["PAYPAL_CLIENT_ID"], os.environ["PAYPAL_CLIENT_SECRET"])
    tok = requests.post(paypal_base() + "/v1/oauth2/token", auth=auth,
                        data={"grant_type": "client_credentials"}, timeout=20)
    tok.raise_for_status()
    r = requests.request(
        method, paypal_base() + path, json=payload, timeout=30,
        headers={"Authorization": "Bearer " + tok.json()["access_token"],
                 "PayPal-Request-Id": uuid.uuid4().hex})
    try:
        body = r.json()
    except ValueError:
        body = {}
    return r.status_code, body


def price_str():
    return f"{UNLOCK_CENTS / 100:.2f}"


@app.post("/api/clips/<int:cid>/unlock")
@login_required
def unlock_clip(u, cid):
    blocked = unverified(u)
    if blocked:
        return blocked
    if not request.is_json:
        return err("JSON required.")
    row = owned_clip(u, cid)
    if not row:
        return err("Clip not found.", 404)
    if clip_status(row) != "locked":
        return err("This clip is not locked.")
    if not paypal_configured():
        return err("Payments are not set up yet.", 503)
    base = os.environ.get("PUBLIC_URL") or request.host_url.rstrip("/")
    try:
        st, res = paypal_api("POST", "/v2/checkout/orders", {
            "intent": "CAPTURE",
            "purchase_units": [{
                "reference_id": f"clip-{cid}",
                "description": ("Unlock clip: " + row["title"])[:120],
                "amount": {"currency_code": "USD", "value": price_str()}}],
            "payment_source": {"paypal": {"experience_context": {
                "brand_name": "Clipzzy", "user_action": "PAY_NOW",
                "return_url": base + "/api/paypal/return",
                "cancel_url": base + "/clips?paid=0"}}}})
    except requests.RequestException:
        return err("Could not reach PayPal. Please try again.", 502)
    link = next((l["href"] for l in res.get("links", [])
                 if l.get("rel") in ("payer-action", "approve")), None)
    if st not in (200, 201) or not res.get("id") or not link:
        return err("Could not start the PayPal checkout. Please try again.", 502)
    db().execute("INSERT OR REPLACE INTO paypal_orders(order_id,user_id,clip_id,created_at) VALUES(?,?,?,?)",
                 (res["id"], u["id"], cid, int(time.time())))
    db().commit()
    return jsonify({"url": link})


def capture_ok(res):
    """True only if PayPal reports a completed capture of exactly the unlock price in USD."""
    if res.get("status") != "COMPLETED":
        return False
    caps = ((res.get("purchase_units") or [{}])[0].get("payments") or {}).get("captures") or []
    return any(c.get("status") == "COMPLETED"
               and (c.get("amount") or {}).get("value") == price_str()
               and (c.get("amount") or {}).get("currency_code") == "USD" for c in caps)


@app.get("/api/paypal/return")
def paypal_return():
    """PayPal sends the customer here after they approve. We capture and verify, then unlock."""
    u = current_user()
    if not u:
        return redirect("/register")
    order_id = request.args.get("token", "")
    row = db().execute("SELECT * FROM paypal_orders WHERE order_id=? AND user_id=?",
                       (order_id, u["id"])).fetchone()
    if not row:
        return redirect("/clips?paid=0")
    if row["status"] == "captured":
        return redirect("/clips?paid=1")
    try:
        st, res = paypal_api("POST", f"/v2/checkout/orders/{order_id}/capture", {})
        if st == 422:  # already captured (e.g. page reloaded): read the order instead
            st, res = paypal_api("GET", f"/v2/checkout/orders/{order_id}")
    except requests.RequestException:
        return redirect("/clips?paid=0")
    if st in (200, 201) and capture_ok(res):
        db().execute("UPDATE paypal_orders SET status='captured' WHERE order_id=?", (order_id,))
        db().execute("UPDATE clips SET unlocked_at=? WHERE id=? AND user_id=? AND unlocked_at IS NULL",
                     (int(time.time()), row["clip_id"], u["id"]))
        db().commit()
        return redirect("/clips?paid=1")
    return redirect("/clips?paid=0")


# ---------- plan subscriptions (PayPal Subscriptions) ----------
PLAN_ENV = {"monthly": "PAYPAL_PLAN_MONTHLY", "annual": "PAYPAL_PLAN_ANNUAL"}


def plan_by_id(plan_id):
    for name, env in PLAN_ENV.items():
        if plan_id and plan_id == os.environ.get(env):
            return name
    return None


def parse_iso(t):
    try:
        return calendar.timegm(time.strptime(str(t)[:19], "%Y-%m-%dT%H:%M:%S"))
    except ValueError:
        return None


def paid_through(res, plan):
    """End of the period the customer last paid for (last payment time + plan length)."""
    last = (res.get("billing_info") or {}).get("last_payment") or {}
    t = parse_iso(last.get("time"))
    return t + PLAN_DAYS[plan] * 86400 if t else None


def refresh_subscription(u):
    """Expire manually paid plans, and re-check PayPal subscriptions (at most every 6 hours)."""
    if (u["plan_until"] and u["plan"] != "free" and not u["sub_id"]
            and time.time() > u["plan_until"]):
        db().execute("UPDATE users SET plan='free', plan_until=NULL WHERE id=?", (u["id"],))
        db().commit()
        u = db().execute("SELECT * FROM users WHERE id=?", (u["id"],)).fetchone()
    if not u["sub_id"] or not paypal_configured():
        return u
    if time.time() - (u["sub_checked"] or 0) < 6 * 3600:
        return u
    try:
        st, res = paypal_api("GET", "/v1/billing/subscriptions/" + u["sub_id"])
    except requests.RequestException:
        return u
    if st != 200:
        return u
    status, plan = res.get("status"), plan_by_id(res.get("plan_id"))
    new, checked, until, keep_sub = u["plan"], int(time.time()), None, True
    if status == "ACTIVE" and plan:
        new = plan
    elif status == "CANCELLED" and plan:
        paid = paid_through(res, plan)
        if paid and paid > time.time():
            new, until, keep_sub = plan, paid, False   # keep access until the paid period ends
        else:
            new = "free"
    elif status in ("CANCELLED", "EXPIRED", "SUSPENDED"):
        new = "free"
    else:
        checked = int(time.time()) - 5 * 3600 - 1800  # undecided: look again in ~30 minutes
    if keep_sub:
        db().execute("UPDATE users SET plan=?, sub_checked=? WHERE id=?", (new, checked, u["id"]))
    else:
        db().execute("UPDATE users SET plan=?, plan_until=?, sub_id=NULL, sub_checked=? WHERE id=?",
                     (new, until, checked, u["id"]))
    db().commit()
    return db().execute("SELECT * FROM users WHERE id=?", (u["id"],)).fetchone()


@app.post("/api/subscribe")
@login_required
def subscribe(u):
    blocked = unverified(u)
    if blocked:
        return blocked
    if not request.is_json:
        return err("JSON required.")
    plan = (request.get_json(silent=True) or {}).get("plan")
    if plan not in PLAN_ENV:
        return err("Choose the monthly or annual plan.")
    plan_id = os.environ.get(PLAN_ENV[plan])
    if not paypal_configured() or not plan_id:
        return err("Payments are not set up yet.", 503)
    u = refresh_subscription(u)
    if u["sub_id"] and u["plan"] != "free":
        return err("You already have an active subscription. Cancel it in PayPal before choosing another plan.", 409)
    base = os.environ.get("PUBLIC_URL") or request.host_url.rstrip("/")
    try:
        st, res = paypal_api("POST", "/v1/billing/subscriptions", {
            "plan_id": plan_id, "custom_id": str(u["id"]),
            "application_context": {
                "brand_name": "Clipzzy", "user_action": "SUBSCRIBE_NOW",
                "return_url": base + "/api/paypal/subscription-return",
                "cancel_url": base + "/pricing"}})
    except requests.RequestException:
        return err("Could not reach PayPal. Please try again.", 502)
    link = next((l["href"] for l in res.get("links", []) if l.get("rel") == "approve"), None)
    if st not in (200, 201) or not link:
        return err("Could not start the PayPal checkout. Please try again.", 502)
    return jsonify({"url": link})


@app.get("/api/paypal/subscription-return")
def subscription_return():
    u = current_user()
    if not u:
        return redirect("/register")
    sid = request.args.get("subscription_id", "")
    try:
        st, res = paypal_api("GET", "/v1/billing/subscriptions/" + sid) if sid else (400, {})
    except requests.RequestException:
        return redirect("/pricing?sub=failed")
    plan = plan_by_id(res.get("plan_id"))
    if st != 200 or not plan or res.get("custom_id") != str(u["id"]):
        return redirect("/pricing?sub=failed")
    if res.get("status") == "ACTIVE":
        db().execute("UPDATE users SET plan=?, sub_id=?, sub_checked=?, plan_until=NULL WHERE id=?",
                     (plan, sid, int(time.time()), u["id"]))
        db().commit()
        return redirect("/register?sub=ok")
    if res.get("status") in ("APPROVED", "APPROVAL_PENDING"):
        db().execute("UPDATE users SET sub_id=?, sub_checked=0 WHERE id=?", (sid, u["id"]))
        db().commit()
        return redirect("/register?sub=pending")
    return redirect("/pricing?sub=failed")


def setup_paypal():
    """One-time: create the PayPal product and the two billing plans, then print their IDs."""
    if not paypal_configured():
        sys.exit("Set PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET first.")
    st, prod = paypal_api("POST", "/v1/catalogs/products",
                          {"name": "Clipzzy", "type": "SERVICE", "category": "SOFTWARE"})
    if st not in (200, 201):
        sys.exit(f"Could not create product: {prod}")
    for name, label, unit, price in (("monthly", "Clipzzy Monthly", "MONTH", "9.00"),
                                     ("annual", "Clipzzy Annual", "YEAR", "20.00")):
        st, plan = paypal_api("POST", "/v1/billing/plans", {
            "product_id": prod["id"], "name": label, "status": "ACTIVE",
            "billing_cycles": [{"frequency": {"interval_unit": unit, "interval_count": 1},
                                "tenure_type": "REGULAR", "sequence": 1, "total_cycles": 0,
                                "pricing_scheme": {"fixed_price": {"value": price, "currency_code": "USD"}}}],
            "payment_preferences": {"auto_bill_outstanding": True,
                                    "setup_fee_failure_action": "CANCEL",
                                    "payment_failure_threshold": 3}})
        if st not in (200, 201):
            sys.exit(f"Could not create {name} plan: {plan}")
        print(f"{PLAN_ENV[name]}={plan['id']}")
    print("Set these as environment variables on your host.")


# ---------- Telebirr manual payments (Ethiopia: promo code, then payment screenshot) ----------
PAYMENTS_DIR = os.environ.get("PAYMENTS_DIR", os.path.join(HERE, "payments"))
PROMO_CODE = os.environ.get("PROMO_CODE", "ethclips").strip().lower()
TELEBIRR_NUMBER = os.environ.get("TELEBIRR_NUMBER", "0907737307")
TELEBIRR_NAME = os.environ.get("TELEBIRR_NAME", "Biruk Sintayehu")
PLAN_DAYS = {"weekly": 7, "monthly": 30, "annual": 365}
MAX_SCREENSHOT = 5 * 1024 * 1024
REF_RE = re.compile(r"^[A-Za-z0-9]{4,40}$")


SCREENSHOT_RETAIN_DAYS = int(os.environ.get("SCREENSHOT_RETAIN_DAYS", "90"))


def purge_old_screenshots():
    cutoff = time.time() - SCREENSHOT_RETAIN_DAYS * 86400
    rows = db().execute("SELECT id, screenshot FROM telebirr_payments WHERE status!='pending' "
                        "AND screenshot!='' AND reviewed_at IS NOT NULL AND reviewed_at<?", (cutoff,)).fetchall()
    for r in rows:
        try:
            os.remove(os.path.join(PAYMENTS_DIR, r["screenshot"]))
        except OSError:
            pass
        db().execute("UPDATE telebirr_payments SET screenshot='' WHERE id=?", (r["id"],))
    if rows:
        db().commit()


ADMIN_DEFAULT = "gimport.t@gmail.com"   # the one and only admin unless ADMIN_EMAILS is set on the host


def admin_emails():
    raw = os.environ.get("ADMIN_EMAILS", ADMIN_DEFAULT)
    return {e.strip().lower() for e in raw.split(",") if e.strip()}


def is_admin(u):
    return u["email"] in admin_emails()


def admin_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        u = current_user()
        if not u or not is_admin(u):
            return err("Not allowed.", 403)
        return fn(u, *a, **kw)
    return wrapper


DEFAULT_ETB = {"weekly": 399, "monthly": 500, "annual": 3000, "unlock": 250}  # birr; override with TELEBIRR_PRICE_*


def telebirr_prices():
    out = {}
    for key, env in (("weekly", "TELEBIRR_PRICE_WEEKLY"), ("monthly", "TELEBIRR_PRICE_MONTHLY"),
                     ("annual", "TELEBIRR_PRICE_ANNUAL"), ("unlock", "TELEBIRR_PRICE_UNLOCK")):
        raw = os.environ.get(env)
        try:
            v = float(raw) if raw else float(DEFAULT_ETB.get(key, 0))
        except ValueError:
            v = 0
        if v > 0:
            out[key] = v
    return out


def telebirr_ready():
    return bool(TELEBIRR_NUMBER) and bool(telebirr_prices())


def sniff_image(data):
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if data.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    return None


def notify_admin(text, photo=None):
    """Send a Telegram message (with the screenshot if possible) to the admin. Never raises."""
    token, chat = os.environ.get("TELEGRAM_BOT_TOKEN"), os.environ.get("TELEGRAM_ADMIN_CHAT_ID")
    if not token or not chat:
        return
    try:
        base = f"https://api.telegram.org/bot{token}/"
        if photo and os.path.exists(photo):
            with open(photo, "rb") as f:
                r = requests.post(base + "sendPhoto", data={"chat_id": chat, "caption": text[:1000]},
                                  files={"photo": f}, timeout=20)
            if r.ok:
                return
        requests.post(base + "sendMessage", data={"chat_id": chat, "text": text}, timeout=20)
    except Exception:  # never include the exception: it can contain the bot token
        print("Telegram alert failed", file=sys.stderr)


def payment_json(r):
    return {"id": r["id"], "kind": r["kind"], "plan": r["plan"], "clip_id": r["clip_id"],
            "amount_etb": r["amount_etb"], "reference": r["reference"], "status": r["status"],
            "note": r["note"], "created_at": r["created_at"]}


@app.post("/api/telebirr/promo")
@login_required
def telebirr_promo(u):
    if not request.is_json:
        return err("JSON required.")
    if limited("promo:%d" % u["id"], n=8, window=600):
        return err("Too many attempts. Try again later.", 429)
    code = str((request.get_json(silent=True) or {}).get("code", "")).strip().lower()
    if not hmac.compare_digest(code.encode(), PROMO_CODE.encode()):
        return err("That promo code is not valid.", 403)
    session["promo_ok"] = True
    return jsonify({"ok": True})


@app.get("/api/telebirr/info")
@login_required
def telebirr_info(u):
    if not session.get("promo_ok"):
        return err("Enter the promo code first.", 403)
    if not telebirr_ready():
        return err("Telebirr payments are not set up yet.", 503)
    return jsonify({"number": TELEBIRR_NUMBER, "name": TELEBIRR_NAME,
                    "prices": telebirr_prices(), "plan_days": PLAN_DAYS})


@app.get("/api/telebirr/mine")
@login_required
def telebirr_mine(u):
    rows = db().execute("SELECT * FROM telebirr_payments WHERE user_id=? ORDER BY created_at DESC LIMIT 20",
                        (u["id"],)).fetchall()
    return jsonify({"payments": [payment_json(r) for r in rows]})


@app.post("/api/telebirr/submit")
@login_required
def telebirr_submit(u):
    blocked = unverified(u)
    if blocked:
        return blocked
    if not session.get("promo_ok"):
        return err("Enter the promo code first.", 403)
    if not telebirr_ready():
        return err("Telebirr payments are not set up yet.", 503)
    if limited("tbsub:%d" % u["id"], n=10, window=3600):
        return err("Too many submissions. Try again later.", 429)
    prices = telebirr_prices()
    kind, plan, clip_id = request.form.get("kind", ""), None, None
    if kind == "plan":
        plan = request.form.get("plan", "")
        if plan not in PLAN_DAYS or plan not in prices:
            return err("Choose a plan.")
        if u["sub_id"] and u["plan"] != "free":
            return err("You already have an active PayPal subscription.", 409)
        amount = prices[plan]
    elif kind == "clip":
        try:
            clip_id = int(request.form.get("clip_id", ""))
        except ValueError:
            return err("Choose a clip.")
        row = owned_clip(u, clip_id)
        if not row or clip_status(row) != "locked":
            return err("That clip is not locked.")
        if "unlock" not in prices:
            return err("Clip unlocking by Telebirr is not available.")
        amount = prices["unlock"]
    else:
        return err("Choose what you are paying for.")
    ref = request.form.get("reference", "").strip()
    if not REF_RE.match(ref):
        return err("Enter the Telebirr transaction number (letters and numbers only).")
    if db().execute("SELECT 1 FROM telebirr_payments WHERE lower(reference)=? AND status IN ('pending','approved')",
                    (ref.lower(),)).fetchone():
        return err("That transaction number was already submitted.", 409)
    waiting = db().execute("SELECT COUNT(*) FROM telebirr_payments WHERE user_id=? AND status='pending'",
                           (u["id"],)).fetchone()[0]
    if waiting >= 3:
        return err("You already have 3 payments waiting for review.", 409)
    f = request.files.get("screenshot")
    if not f:
        return err("Attach your payment screenshot.")
    data = f.read(MAX_SCREENSHOT + 1)
    if len(data) > MAX_SCREENSHOT:
        return err("The screenshot is too large (max 5 MB).", 413)
    ext = sniff_image(data)
    if not ext:
        return err("The screenshot must be a PNG, JPG or WebP image.")
    rel = os.path.join(str(u["id"]), uuid.uuid4().hex + "." + ext)
    dest = os.path.join(PAYMENTS_DIR, rel)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    with open(dest, "wb") as out:
        out.write(data)
    cur = db().execute(
        "INSERT INTO telebirr_payments(user_id,kind,plan,clip_id,amount_etb,reference,screenshot,created_at) "
        "VALUES(?,?,?,?,?,?,?,?)", (u["id"], kind, plan, clip_id, amount, ref, rel, int(time.time())))
    db().commit()
    r = db().execute("SELECT * FROM telebirr_payments WHERE id=?", (cur.lastrowid,)).fetchone()
    item = f"{plan} plan" if kind == "plan" else f"unlock clip #{clip_id}"
    site = os.environ.get("PUBLIC_URL") or request.host_url.rstrip("/")
    alert = (f"New Telebirr payment\n{u['email']}\n{item}\n{amount:g} ETB\n"
             f"Transaction: {ref}\nReview: {site}/admin/payments")
    threading.Thread(target=notify_admin, args=(alert, dest), daemon=True).start()
    return jsonify(payment_json(r)), 201


@app.get("/api/admin/payments")
@admin_required
def admin_list_payments(admin):
    purge_old_screenshots()
    status = request.args.get("status", "pending")
    if status not in ("pending", "approved", "rejected"):
        return err("Bad status.")
    rows = db().execute(
        "SELECT p.*, u.email FROM telebirr_payments p JOIN users u ON u.id=p.user_id "
        "WHERE p.status=? ORDER BY p.created_at DESC LIMIT 100", (status,)).fetchall()
    out = []
    for r in rows:
        d = payment_json(r)
        d["email"] = r["email"]
        out.append(d)
    return jsonify({"payments": out})


@app.get("/api/admin/payments/<int:pid>/screenshot")
@admin_required
def admin_screenshot(admin, pid):
    r = db().execute("SELECT screenshot FROM telebirr_payments WHERE id=?", (pid,)).fetchone()
    if not r:
        return err("Not found.", 404)
    path = os.path.realpath(os.path.join(PAYMENTS_DIR, r["screenshot"]))
    if not path.startswith(os.path.realpath(PAYMENTS_DIR) + os.sep) or not os.path.exists(path):
        return err("Not found.", 404)
    return send_file(path)


@app.post("/api/admin/payments/<int:pid>/review")
@admin_required
def admin_review(admin, pid):
    if not request.is_json:
        return err("JSON required.")
    d = request.get_json(silent=True) or {}
    action, note = d.get("action"), str(d.get("note", "")).strip()[:300]
    if action not in ("approve", "reject"):
        return err("Choose approve or reject.")
    r = db().execute("SELECT * FROM telebirr_payments WHERE id=?", (pid,)).fetchone()
    if not r:
        return err("Not found.", 404)
    if r["status"] != "pending":
        return err("This payment was already reviewed.", 409)
    now = int(time.time())
    if action == "approve":
        if r["kind"] == "plan":
            t = db().execute("SELECT * FROM users WHERE id=?", (r["user_id"],)).fetchone()
            start = max(now, t["plan_until"] or 0) if t["plan"] == r["plan"] else now
            until = start + PLAN_DAYS[r["plan"]] * 86400
            db().execute("UPDATE users SET plan=?, plan_until=? WHERE id=?", (r["plan"], until, r["user_id"]))
        else:
            db().execute("UPDATE clips SET unlocked_at=? WHERE id=? AND user_id=? AND unlocked_at IS NULL",
                         (now, r["clip_id"], r["user_id"]))
    db().execute("UPDATE telebirr_payments SET status=?, note=?, reviewed_at=? WHERE id=?",
                 ("approved" if action == "approve" else "rejected", note, now, pid))
    db().commit()
    return jsonify({"ok": True})


# ---------- email: verification and password reset ----------
def email_enabled():
    """Email needs an SMTP server and the public site address (used in links; never the Host header)."""
    return bool(os.environ.get("SMTP_HOST") and os.environ.get("PUBLIC_URL")
                and (os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USER")))


def _smtp_send(msg):
    try:
        host, port = os.environ["SMTP_HOST"], int(os.environ.get("SMTP_PORT", "587"))
        conn = smtplib.SMTP_SSL(host, port, timeout=20) if port == 465 else smtplib.SMTP(host, port, timeout=20)
        with conn:
            if port != 465:
                conn.starttls()
            if os.environ.get("SMTP_USER"):
                conn.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASSWORD", ""))
            conn.send_message(msg)
    except Exception:  # keep details out of logs: they can contain credentials
        print("Email send failed", file=sys.stderr)


def send_email(to, subject, body):
    msg = EmailMessage()
    msg["From"] = os.environ.get("SMTP_FROM") or os.environ["SMTP_USER"]
    msg["To"], msg["Subject"] = to, subject
    msg.set_content(body)
    threading.Thread(target=_smtp_send, args=(msg,), daemon=True).start()


def make_token(user_id, kind, hours):
    raw = secrets.token_urlsafe(32)
    now = int(time.time())
    db().execute("DELETE FROM email_tokens WHERE user_id=? AND kind=?", (user_id, kind))
    db().execute("INSERT INTO email_tokens(user_id,kind,token_hash,expires_at,created_at) VALUES(?,?,?,?,?)",
                 (user_id, kind, hashlib.sha256(raw.encode()).hexdigest(), now + int(hours * 3600), now))
    db().commit()
    return raw


def find_token(raw, kind):
    row = db().execute("SELECT * FROM email_tokens WHERE token_hash=? AND kind=?",
                       (hashlib.sha256(str(raw).encode()).hexdigest(), kind)).fetchone()
    return row if row and row["expires_at"] >= time.time() else None


def site_url():
    return os.environ["PUBLIC_URL"].rstrip("/")


def send_verification(u):
    if not email_enabled() or u["email_verified"]:
        return False
    link = f"{site_url()}/verify?token={make_token(u['id'], 'verify', 48)}"
    send_email(u["email"], "Verify your Clipzzy email",
               f"Welcome to Clipzzy!\n\nConfirm your email address by opening this link (valid for 48 hours):\n{link}\n\n"
               "If you did not create an account, you can ignore this message.")
    return True


def unverified(u):
    """An error response if email verification is on and this account has not verified yet."""
    if email_enabled() and not u["email_verified"]:
        return err("Please verify your email first. Check your inbox, or use the resend button on your account page.", 403)
    return None


@app.get("/verify")
def verify_email():
    row = find_token(request.args.get("token", ""), "verify")
    if not row:
        return redirect("/register?verified=0")
    db().execute("UPDATE users SET email_verified=1 WHERE id=?", (row["user_id"],))
    db().execute("DELETE FROM email_tokens WHERE user_id=? AND kind='verify'", (row["user_id"],))
    db().commit()
    return redirect("/register?verified=1")


@app.post("/api/resend-verification")
@login_required
def resend_verification(u):
    if not request.is_json:
        return err("JSON required.")
    if not email_enabled():
        return err("Email is not set up yet. Please contact support.", 503)
    if u["email_verified"]:
        return jsonify({"ok": True, "message": "Your email is already verified."})
    if limited("resend:%d" % u["id"], n=3, window=3600):
        return err("Too many requests. Try again in an hour.", 429)
    send_verification(u)
    return jsonify({"ok": True, "message": "Verification email sent. Check your inbox."})


@app.get("/reset")
def reset_page():
    resp = send_from_directory(HERE, "reset.html")
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.post("/api/forgot")
def forgot_password():
    if not request.is_json:
        return err("JSON required.")
    if limited("forgot:" + (request.remote_addr or "?"), n=10, window=3600):
        return err("Too many attempts. Try again later.", 429)
    if not email_enabled():
        return err("Password reset by email is not set up yet. Please message us for help.", 503)
    email = str((request.get_json(silent=True) or {}).get("email", "")).strip().lower()
    generic = jsonify({"ok": True, "message": "If that email has an account, we sent a reset link. It works for 1 hour."})
    if not EMAIL_RE.match(email) or limited("forgot-e:" + email, n=3, window=3600):
        return generic
    u = db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if u and email not in admin_emails():   # the owner account is reset from the server only
        link = f"{site_url()}/reset?token={make_token(u['id'], 'reset', 1)}"
        send_email(email, "Reset your Clipzzy password",
                   f"Someone asked to reset the password for your Clipzzy account.\n\nChoose a new password here (valid for 1 hour, works once):\n{link}\n\n"
                   "If this was not you, ignore this message. Your password has not changed.")
    return generic


@app.post("/api/reset")
def reset_password():
    if not request.is_json:
        return err("JSON required.")
    if limited("reset:" + (request.remote_addr or "?"), n=10, window=3600):
        return err("Too many attempts. Try again later.", 429)
    d = request.get_json(silent=True) or {}
    pw = str(d.get("password", ""))
    if not 8 <= len(pw) <= 128:
        return err("Password must be 8 to 128 characters.")
    row = find_token(d.get("token", ""), "reset")
    if not row:
        return err("This reset link is invalid or has expired. Please request a new one.")
    db().execute("UPDATE users SET pw_hash=?, email_verified=1, session_ver=session_ver+1 WHERE id=?",
                 (generate_password_hash(pw), row["user_id"]))
    db().execute("DELETE FROM email_tokens WHERE user_id=?", (row["user_id"],))
    db().commit()
    session.clear()
    return jsonify({"ok": True})


@app.errorhandler(413)
def too_big(_e):
    return err(f"That file is too large (limit {MAX_UPLOAD_MB} MB).", 413)


def create_admin(email, password):
    """Create (or recreate) the admin account from the server. Replaces any existing row,
    so a session or account created earlier by someone else is invalidated."""
    email = email.strip().lower()
    if email not in admin_emails():
        sys.exit(f"{email} is not in the admin list ({', '.join(sorted(admin_emails()))}).")
    if not 8 <= len(password) <= 128:
        sys.exit("Password must be 8 to 128 characters.")
    now = int(time.time())
    with sqlite3.connect(DB_PATH) as c:
        old = c.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
        if old:
            for table in ("exports", "clips", "telebirr_payments", "paypal_orders", "email_tokens"):
                c.execute(f"DELETE FROM {table} WHERE user_id=?", (old[0],))
            c.execute("DELETE FROM users WHERE id=?", (old[0],))
        c.execute("INSERT INTO users(email,pw_hash,plan,created_at,free_start,email_verified) VALUES(?,?,?,?,?,1)",
                  (email, generate_password_hash(password), "annual", now, now))
    return email


if __name__ == "__main__":
    if len(sys.argv) in (2, 3) and sys.argv[1] == "create-admin":
        import getpass
        who = sys.argv[2] if len(sys.argv) == 3 else ADMIN_DEFAULT
        pw = getpass.getpass("New admin password: ")
        if pw != getpass.getpass("Repeat password: "):
            sys.exit("Passwords do not match.")
        print("Admin account ready:", create_admin(who, pw))
        sys.exit(0)
    if len(sys.argv) == 4 and sys.argv[1] == "set-plan":
        email, plan = sys.argv[2].lower(), sys.argv[3]
        if plan not in PLANS:
            sys.exit("Plan must be one of: " + ", ".join(PLANS))
        with sqlite3.connect(DB_PATH) as c:
            n = c.execute("UPDATE users SET plan=? WHERE email=?", (plan, email)).rowcount
        sys.exit(f"Set {email} to {plan}." if n else f"No user with email {email}.")
    if len(sys.argv) == 2 and sys.argv[1] == "setup-paypal":
        setup_paypal()
        sys.exit(0)
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8000")))
