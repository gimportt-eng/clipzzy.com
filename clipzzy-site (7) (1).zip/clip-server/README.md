# Clipzzy

Pages: `/help` help center (Instagram @21anu_21, Telegram @clipzzy_bot) · `/` landing · `/app` clipper · `/pricing` · `/register` sign up / log in · `/clips` saved clips · `/terms`

## Plans
Free (30 days) · Weekly (Telebirr only, 25 exports per week) · Monthly ($9, PayPal or Telebirr) · Annual ($20, PayPal or Telebirr). The clipper's "Make 7 viral clips" button suggests 7 short clips per long video, ranked by a loudness score.

## Run locally
```
pip install -r requirements.txt        # ffmpeg must be installed
SECRET_KEY=anything COOKIE_SECURE=0 python server.py
```
Open http://localhost:8000. `COOKIE_SECURE=0` is for local http only.

## Deploy (Render)
1. Push this folder to GitHub.
2. In Render: New > Blueprint, pick the repo (it reads `render.yaml`: Docker, 1 GB disk, generated SECRET_KEY).
3. Add clipzzy.com under Settings > Custom Domains and copy the DNS records to your registrar.
4. Set the environment variables below.

## Environment variables
| Name | Purpose |
|---|---|
| `SECRET_KEY` | Signs login cookies (Render generates it) |
| `DB_PATH`, `CLIPS_DIR` | Where the database and saved clips live (`/data/...` on Render) |
| `PUBLIC_URL` | e.g. `https://clipzzy.com`, used for PayPal return links |
| `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET` | From developer.paypal.com > Apps |
| `PAYPAL_ENV` | `sandbox` while testing, `live` for real money |
| `PAYPAL_PLAN_MONTHLY`, `PAYPAL_PLAN_ANNUAL` | Created by `python server.py setup-paypal` |
| `PROMO_CODE` | Code that unlocks the Telebirr payment page (default `ethclips`) |
| `ADMIN_EMAILS` | Who can review payments at `/admin/payments`. Defaults to `gimport.t@gmail.com` only. Do not add other emails |
| `TELEBIRR_NUMBER`, `TELEBIRR_NAME` | The Telebirr number and account name customers pay (default 0907737307, Biruk Sintayehu) |
| `TELEBIRR_PRICE_WEEKLY`, `TELEBIRR_PRICE_MONTHLY`, `TELEBIRR_PRICE_ANNUAL`, `TELEBIRR_PRICE_UNLOCK` | Prices in birr (defaults 399, 500, 3000, and 250 to unlock one clip) |
| `TELEGRAM_BOT_TOKEN`, `TELEGRAM_ADMIN_CHAT_ID` | Optional: Telegram alert to you for each new Telebirr payment |
| `SCREENSHOT_RETAIN_DAYS` | Reviewed payment screenshots are deleted after this many days (default 90) |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM` | Outgoing email for verification and password reset (see Email below) |
| `PAYMENTS_DIR` | Where payment screenshots are stored (`/data/payments` on Render) |
| `MAX_CLIP_SECONDS`, `MAX_ACTIVE_CLIPS`, `MAX_UPLOAD_MB`, `RETAIN_LOCKED_DAYS` | Optional limits |

## PayPal setup
1. Create a PayPal Business account and an app at developer.paypal.com (start in Sandbox).
2. Set `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, `PAYPAL_ENV=sandbox`.
3. Run `python server.py setup-paypal` once. It prints the two plan IDs; set them as `PAYPAL_PLAN_MONTHLY` and `PAYPAL_PLAN_ANNUAL`.
4. Test with PayPal sandbox buyer accounts. For live, repeat steps 2-3 with live keys and `PAYPAL_ENV=live`.

## Test checklist
- Sign up, log out, log in.
- Free account: export a link clip (watermark, 30 s max). Check 8th export of the day is refused.
- Make a clip older than 4 days (or set `created_at` back in the database): it shows Locked; Unlock pays $4 via PayPal and unlocks it.
- Subscribe to Monthly in sandbox: plan changes to Monthly. Cancel in PayPal: the plan stays until the paid period ends, then returns to Free (checked about every 6 hours).

## Telebirr (Ethiopia)
1. Defaults are already set: number 0907737307 (Biruk Sintayehu), Weekly 399, Monthly 500, Annual 3000 and clip unlock 250 birr. Promo code: `ethclips`.
2. Customers go to `/pay/telebirr` (linked from pricing and from locked clips), enter the promo code, pay, and upload a screenshot with the transaction number.
3. You open `/admin/payments` while logged in as the admin, compare each screenshot with your Telebirr history (amount, transaction number), and Approve or Reject.
4. Approving a plan gives 7 days (Weekly), 30 days (Monthly) or 365 days (Annual), extended if they renew early; the plan returns to Free when it ends. Approving a clip unlocks it.
5. Each transaction number can only be used once while pending or approved. Screenshots are kept on disk for your records.
The promo code only gates the page; it is not a strong secret.

### Telegram alerts (optional)
1. In Telegram, open @BotFather, create a bot, and copy its token into `TELEGRAM_BOT_TOKEN`.
2. Send any message to your new bot, then open `https://api.telegram.org/bot<TOKEN>/getUpdates` and copy the `chat` `id` into `TELEGRAM_ADMIN_CHAT_ID`.
3. Each new Telebirr submission then sends you the details and the screenshot. The screenshot is sent to Telegram, so only use your own private chat.

## Email: verification and password reset
Both features need an SMTP mail account and `PUBLIC_URL` (links in emails always use `PUBLIC_URL`, never the address a visitor typed, so nobody can forge reset links).
1. Pick a mail sender. For a quick start you can use Gmail: turn on 2-step verification, create an App Password, then set `SMTP_HOST=smtp.gmail.com`, `SMTP_PORT=587`, `SMTP_USER=you@gmail.com`, `SMTP_PASSWORD=<app password>`. For real customers a transactional service (Brevo, Resend, Mailgun) with your domain's SPF and DKIM records lands in inboxes more reliably, and Gmail limits how many emails you can send per day.
2. Set `SMTP_FROM` to the address emails come from (for example `Clipzzy <hello@clipzzy.com>`).
3. Test: sign up with a new email, open the link, then use "Forgot your password?" on the log-in page.

How it behaves:
- New accounts must verify their email before they can export link clips, save clips, subscribe, unlock clips or send Telebirr payments. They can still log in and see their account, and there is a resend button.
- Verification links last 48 hours. Reset links last 1 hour and work once. Resetting a password also verifies the email and logs the account out on every device.
- "Forgot your password?" gives the same answer whether or not the email has an account, and is rate limited.
- The owner account cannot be reset by email. Use `python server.py create-admin`.
- If SMTP is not set up, verification is not enforced and the reset page says it is not available. When you turn email on later, existing accounts that never verified must verify first.

## Admin (owner only)
The only admin is `gimport.t@gmail.com`. Nobody can register that email on the website, so no one can take it over. Create your admin account once from the server (on Render: Shell tab):
```
python server.py create-admin
```
It asks for a password. Then log in at `/register` with that email and open `/admin/payments`. Running the command again resets the password and logs out any older session for that account. Keep your Render and GitHub accounts protected with two-factor login, because anyone with server access is effectively an admin.

## Admin tools
`python server.py set-plan user@example.com monthly` sets a plan by hand.

## Known limits
- A cancelled PayPal subscription keeps its plan until the period of the last payment ends (last payment date plus 30 or 365 days).
- No refunds screen yet. Email verification and password reset need the SMTP settings above.
- Clips exported from an uploaded file are limited in the browser; link clips are limited on the server.
- Downloading from YouTube may break their terms. Consider allowing only users' own content.
- SQLite and local disk are fine to start; move to Postgres and object storage for scale.
- `terms.html` is a template. Get legal review.
